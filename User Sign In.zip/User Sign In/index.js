// console.log("hdjwdh");
function validate() {
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    // var password = document.getElementById('password').value;
    // var cpassword = document.getElementById('cpassword').value;
    console.log("username",username)
    checkusername(username);
    checkemail(email);
    // checkpassword(password);
    // checkpasswordmatch(password, cpassword);
  }
  function checkusername(username) {
    if (username.length > 7) {
      // document.getElementById('username').classList.replace('error', 'success');
      document.getElementById('username').classList.remove('error');
      document.getElementById('username_error').innerHTML=''
    } 
    else {
      document.getElementById('username').classList.add('error');
      document.getElementById('username_error').innerHTML='username must contain at least 8 char'
    }
  }
  function checkemail(email) {
    if (email.includes('@itbhu.ac.in')) {
      // document.getElementById('email').classList.replace('error', 'success');
      document.getElementById('email').classList.remove('error');
      document.getElementById('email_error').innerText=''
    } 
    else {
      document.getElementById('email').classList.add('error');
      document.getElementById('email_error').innerText='email must contain @itbhu.ac.in'
    }
  }
  
  document.getElementById('submit').addEventListener("click",validate);
  // function checkemail(){
  
  // }
  // function checkpassword(){
  
  // }
  // function checkpasswordmatch(){
  
  // }
  